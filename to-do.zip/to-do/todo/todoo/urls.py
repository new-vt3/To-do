# project-level urls.py (same level as settings.py)
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('todo.urls')),   # This line includes URLs from your 'todo' app at root
]
