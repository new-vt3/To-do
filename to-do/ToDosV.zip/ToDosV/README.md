Django To-Do List (complete) — ready to run

Steps to run:
1. Create a virtualenv:
   python -m venv venv
   source venv/bin/activate   (or venv\Scripts\activate on Windows)
2. Install requirements:
   pip install -r requirements.txt
3. Run migrations:
   python manage.py migrate
4. Create superuser (optional):
   python manage.py createsuperuser
5. Run server:
   python manage.py runserver

App overview:
- Project: todo_project
- App: tasks
- Features: Register, Login, Logout, Create/Update/Delete tasks, mark complete, user-specific tasks.
- Frontend: Bootstrap 5 via CDN
