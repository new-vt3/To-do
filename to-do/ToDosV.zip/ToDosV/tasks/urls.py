from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),
    path('tasks/', views.todo_list, name='todo-list'),
    path('tasks/create/', views.task_create, name='task-create'),
    path('tasks/<int:pk>/edit/', views.task_update, name='task-edit'),
    path('tasks/<int:pk>/delete/', views.task_delete, name='task-delete'),
    path('tasks/<int:pk>/toggle/', views.toggle_complete, name='task-toggle'),
]
